<?php

// mengelompokan folder
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AnimalController extends Controller
{



    public $animals = [
        ["id" => "Harimau",],
        ["id" => "Ayam",],
        ["id" => "kambing"]
    ];



    public function index()
    {
        // echo "Menampilkan data animals : ";

        // PAGE INI COCOK UNTUK ARRAY UMUM
        foreach ($this->animals as $binatang) {
            #as digunakan untuk mengganti parameter animal menjadi kewan
            echo "<br>" . "$binatang[id]" . PHP_EOL;
            echo "<br>";
        }
    }

    public function store(Request $request)
    {
        echo "Nama hewan :" . array_push($this->animals, $request);
        $this->index();
        echo "<br>";
        // echo "Menambahkan hewan baru";



    }

    public function update(Request $request, $id)
    {
        echo "Nama hewan: $request->nama";
        echo "<br>";
        echo "Mengupdate data hewan id $id";
    }

    public function destroy($id)
    {
        // echo "Menghapus data hewan id $id";

        // $animals = collect([
        //     "kucing","ayam","kambing"
        // ]);



        if (isset($this->animal[$id])) {
            return $this->index = array_splice($this->animal,  $id, 1);
        }
    }
}